import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, interval } from 'rxjs';
import { take, map } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'audimaAngular';
  url = 'http://localhost/get/dados';
  dados: any;
  constructor(private http: HttpClient){
    this.getDados();
  }

  async getDados() {
    let headers = new HttpHeaders({
      'Content-Type':  'application/json'
    });

    interval(1000)
    .subscribe(() => 
      this.http.get(this.url, {headers: headers}).subscribe((response) => {
        this.dados = response; 
      }, err => { 
        console.log(err);
      })
    );
  }
}
